var HTS_CL_POINTS = [
    [
        35.3667,
        -119.0167,
        "bak",
        "bakersfield"
    ],
    [
        39.74,
        -121.837478,
        "chc",
        "chico"
    ],
    [
        36.863632,
        -119.946973,
        "fre",
        "fresno / madera"
    ],
    [
        38.847073,
        -121.026125,
        "gld",
        "gold country"
    ],
    [
        36.3275,
        -119.6456,
        "hnf",
        "hanford-corcoran"
    ],
    [
        40.8,
        -123.8,
        "hmb",
        "humboldt county"
    ],
    [
        33.04,
        -115.35,
        "imp",
        "imperial county"
    ],
    [
        34.1216,
        -116.93,
        "inl",
        "inland empire"
    ],
    [
        33.964997,
        -118.409009,
        "lax",
        "los angeles",
        "wst",
        "1"
    ],
    [
        34.2385,
        -118.4628,
        "lax",
        "los angeles",
        "sfv",
        "2"
    ],
    [
        34.05,
        -118.321369,
        "lax",
        "los angeles",
        "lac",
        "3"
    ],
    [
        34.1019,
        -118.1028,
        "lax",
        "los angeles",
        "sgv",
        "4"
    ],
    [
        33.7683,
        -118.1956,
        "lax",
        "los angeles",
        "lgb",
        "5"
    ],
    [
        34.7514,
        -118.2523,
        "lax",
        "los angeles",
        "ant",
        "6"
    ],
    [
        39.43,
        -123.43,
        "mdo",
        "mendocino county"
    ],
    [
        37.3,
        -120.4833,
        "mer",
        "merced"
    ],
    [
        37.6614,
        -120.9944,
        "mod",
        "modesto"
    ],
    [
        36.8,
        -121.9,
        "mtb",
        "monterey bay"
    ],
    [
        33.67,
        -117.78,
        "orc",
        "orange county"
    ],
    [
        33.8303,
        -116.5453,
        "psp",
        "palm springs"
    ],
    [
        40.5833,
        -122.3667,
        "rdd",
        "redding"
    ],
    [
        39.0917,
        -120.0417,
        "rno",
        "reno / tahoe"
    ],
    [
        38.5556,
        -121.4689,
        "sac",
        "sacramento"
    ],
    [
        32.715,
        -117.1625,
        "sdo",
        "san diego",
        "csd",
        "1"
    ],
    [
        33.277277,
        -116.972563,
        "sdo",
        "san diego",
        "nsd",
        "2"
    ],
    [
        32.829138,
        -116.907812,
        "sdo",
        "san diego",
        "esd",
        "3"
    ],
    [
        32.589933,
        -117.056594,
        "sdo",
        "san diego",
        "ssd",
        "4"
    ],
    [
        35.2742,
        -35.2742,
        "slo",
        "san luis obispo"
    ],
    [
        34.4258,
        -34.4258,
        "sba",
        "santa barbara"
    ],
    [
        34.9514,
        -34.9514,
        "smx",
        "santa maria"
    ],
    [
        32.715,
        -117.1625,
        "sfo",
        "SF bay area",
        "sfc",
        "1"
    ],
    [
        37.33,
        -121.94,
        "sfo",
        "SF bay area",
        "sby",
        "2"
    ],
    [
        37.7,
        -122,
        "sfo",
        "SF bay area",
        "eby",
        "3"
    ],
    [
        37.583333,
        -122.401111,
        "sfo",
        "SF bay area",
        "pen",
        "4"
    ],
    [
        38.04,
        122.74,
        "sfo",
        "SF bay area",
        "nby",
        "5"
    ],
    [
        36.9719,
        -122.0264,
        "sfo",
        "SF bay area",
        "scz",
        "6"
    ],
    [
        41.5833,
        -122.5,
        "ssk",
        "siskiyou county"
    ],
    [
        37.9756,
        -121.3008,
        "stk",
        "stockton"
    ],
    [
        40.4164,
        -120.6531,
        "ssn",
        "susanville"
    ],
    [
        34.36,
        -119.15,
        "oxr",
        "ventura county"
    ],
    [
        36.3167,
        -119.3,
        "vis",
        "visalia-tulare"
    ],
    [
        39.134792,
        -121.626201,
        "ybs",
        "yuba-sutter"
    ]
]