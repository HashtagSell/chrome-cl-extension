var tmp_listing_urls = {
	'private': "https://post.craigslist.org/u/lJWZajJt5RG1IHQqruyhtg", 
	'public': "http://sfbay.craigslist.org/sfc/ele/5257102435.html"
}